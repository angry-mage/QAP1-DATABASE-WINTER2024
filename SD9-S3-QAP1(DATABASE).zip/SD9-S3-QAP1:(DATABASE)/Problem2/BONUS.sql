SELECT actor.actor_id, first_name, last_name, COUNT (film.title)  FROM actor
JOIN film_actor ON film_actor.actor_id = actor.actor_id
JOIN film ON film_actor.film_id = film.film_id
WHERE first_name = 'Penelope'
GROUP BY actor.actor_id
ORDER BY COUNT (film.title) DESC;
