SELECT actor_id FROM film_actor
GROUP BY actor_id
