SELECT actor.actor_id, first_name || ' ' || last_name AS full_name, film.film_id, film.title FROM actor
INNER JOIN film_actor ON film_actor.actor_id = actor.actor_id
INNER JOIN film ON film_actor.film_id = film.film_id;