SELECT title, release_year, rental_rate, rating FROM film
