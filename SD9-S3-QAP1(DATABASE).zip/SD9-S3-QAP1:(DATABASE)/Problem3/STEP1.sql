INSERT INTO public.customer(
	store_id, first_name, last_name, email, address_id, active)
	VALUES (2, 'Kaz', 'Eagles', 'kaz.eag@mail.com', 606, 1);
	