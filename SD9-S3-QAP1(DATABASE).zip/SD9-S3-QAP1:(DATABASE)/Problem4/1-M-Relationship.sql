SELECT * FROM public."Customers"
INNER JOIN public."Orders" ON public."Customers".customer_id = public."Orders".customer_id;
