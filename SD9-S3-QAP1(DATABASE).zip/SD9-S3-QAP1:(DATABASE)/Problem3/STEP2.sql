UPDATE public.customer
	SET address_id= 607
	WHERE last_name = 'Eagles';