SELECT title, rating FROM film
ORDER BY rating DESC
