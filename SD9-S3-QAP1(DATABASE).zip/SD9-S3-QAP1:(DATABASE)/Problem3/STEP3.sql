DELETE FROM public.address
	WHERE address_id = 606;