SELECT title, release_year, rental_rate, rating FROM film
WHERE rating = 'PG-13'
